
# v1.1.0
## 11/23/2018

1. [](#improved)
    * Add pull-request [#7](https://github.com/clemdesign/grav-plugin-language-selector/pull/7): Need jQuery 1.8 or later.
    

# v1.0.1
## 08/10/2018

1. [](#improved)
    * Add pull-request [#1](https://github.com/clemdesign/grav-plugin-language-selector/pull/1)
    
2. [](#bugfix)
    * Fix issue [#2](https://github.com/clemdesign/grav-plugin-language-selector/issues/2)
      -> Improve jQuery integration

# v1.0.0
## 07/22/2017

1. [](#new)
    * ChangeLog started...
