---
title: 'Bakery Slider'
visible: false
content:
    items: '@self.children'
---

