This Net.LDAP2 package was modified to use MYPEAR instead of PEAR.  
This was done to avoid conflicts will older versions of PEAR running on Grav.