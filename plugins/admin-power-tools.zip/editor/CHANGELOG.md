# v0.1.8
##  06/05/2018

1. [](#bugfix)
    * Remove negative lookbehind from regex
    
# v0.1.7
##  06/05/2018

1. [](#maintainance)
    * Remove console.log from AJAX response.
    
2. [](#bugfix)
    * Do not rely on admin blank.html.twig.
    
# v0.1.6
##  06/04/2018

1. [](#new)
    * Add support for YAML files.
    
# v0.1.5
##  05/21/2018

1. [](#bugfix)
    * Add workaround for gm-scrollbar issue.
    * Do not load file already loaded in twig.

# v0.1.4
##  04/29/2018

1. [](#bugfix)
    * Commit missing lib files that were excluded.

# v0.1.3
##  04/24/2018

1. [](#bugfix)
    * Avoid conflict with admin editor twig 

# v0.1.2
##  04/12/2018

1. [](#bugfix)
    * Fix dependency versions 

# v0.1.1
##  04/11/2018

1. [](#bugfix)
    * Catch exceptions in version check 

# v0.1.0
##  04/09/2018

1. [](#new)
    * Initial commit
