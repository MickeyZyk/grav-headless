---
title: Editor
cache:
    enabled: false
never_cache_twig: true
    
access:
  admin.login: true
  admin.super: true
  
editable: false
 
---
