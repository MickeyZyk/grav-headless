---
title: 'Pojištovna Direct Case Study'
logo_dark: dummy.png
heading_tag: 'Strategic planning and Consultancy'
heading_one: 'Helped Direct Insurance see the future role of insurance business'
toggle: '-1'
big_image: direct.jpg
video: 'null'
logo_light: dummy.png
heading_two: 'Pojištovna Direct Case Study'
media: 'direct.jpg,dummy.png'
---

