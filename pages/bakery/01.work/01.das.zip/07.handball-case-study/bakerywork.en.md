---
title: 'Handball Association'
logo_dark: dummy.png
heading_tag: 'Strategic planning and Consultancy'
heading_one: 'Refreshed traditional sport of Handball to be motivating and inspirational again'
toggle: '1'
big_image: handball.jpg
video: 'null'
logo_light: dummy.png
heading_two: 'Handball Case Study'
media: 'handball.jpg,dummy.png'
---

