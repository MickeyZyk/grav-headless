---
title: 'MetLife Insurance'
logo_dark: metlife.png
heading_tag: 'Strategic planning and Consultancy'
heading_one: 'Helped MetLife Insurance understand the true emotions behind children''s insurance'
toggle: '1'
big_image: metlife.jpg
video: 'null'
logo_light: metlife.png
heading_two: 'MET LIFE CASE STUDY'
media: metlife.png
---

