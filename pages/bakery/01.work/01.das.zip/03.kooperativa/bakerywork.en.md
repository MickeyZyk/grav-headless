---
title: Kooperativa
logo_dark: kooperativa.png
heading_tag: Ideation
heading_one: 'How to make people think OF SERIOUS TOPICS?'
toggle: '1'
one_way: 'Bet on fear.'
new_way: 'How about using humor where you least expect it?'
big_image: KOOP.jpg
video: 'null'
logo_light: light_kooperativa.png
heading_two: 'KOOPERATIVA CASE STUDY'
media: 'KOOP.jpg,10565094_821160411227828_1863521926062723614_n.jpg,kooperativa.png,light_kooperativa.png'
---

