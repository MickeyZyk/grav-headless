---
title: Staropramen
logo_dark: sp.png
heading_tag: 'Strategic Planning'
heading_one: 'How to give kick a national brand of beer? How to help it grow?'
toggle: '1'
one_way: 'Play the Beer Fun (Nobody believes that is funny)'
new_way: 'Exploring the place of origin, its people and their specific way of life.'
big_image: Staropramen_picture_work-section.jpg
video: 'https://youtu.be/KCela48LYuo'
logo_light: light_SP.png
heading_two: 'STAROPRAMEN CASE STUDY'
media: 'Logo_Pivovary Staropramen-a.png,staropramen.jpg,sp.png,light_SP.png,Staropramen_picture_work-section.jpg'
---

