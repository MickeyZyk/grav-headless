---
title: 'Czech Inn '
logo_dark: dummy.png
heading_tag: Innovation
heading_one: 'Together with Czech Inn Hotels developed strategies for new ways of accommodation'
toggle: '-1'
big_image: czechinn.jpg
video: 'null'
logo_light: dummy.png
heading_two: 'Czech Inn Case Study'
media: 'czechinn.jpg,dummy.png'
---

