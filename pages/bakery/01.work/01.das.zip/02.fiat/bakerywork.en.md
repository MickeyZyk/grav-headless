---
title: Fiat
logo_dark: dark_logo_fiat.png
heading_tag: Ideation
heading_one: 'How to launch a new crossover blending design & practicality to women in overcrowded market?'
one_way: 'Use TV and mass marketing to get the message across.'
new_way: 'How about giving your future customers a chance to come up with their own view of practicality?'
big_image: fiat.jpg
video: 'https://youtu.be/nq2_TJRua0A'
logo_light: light_logo_fiat.png
category: AWARD
category_name: 'FIAT 500X'
heading_two: 'HERE WE NEED A HEADLINE'
media: 'dark_logo_fiat.png,light_logo_fiat.png,fiat_video.jpg'
---

