---
title: Authors
visible: false
content:
    items: '@self.children'
---

