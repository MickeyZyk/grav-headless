---
title: 'John Doe'
subheading: "”Díky Vám jsem našel i směr, když to řeknu nadneseně - smysl pracovního života.\_Protože jsem pořád nevěděl, co by mě bavilo a pak jste přišli Vy a naučili jste mě svobodně, a kolikrát bezhlavě, psát nesmysly, které i sem tam někoho zaujmou. Takže ač jsem dodělal IT školu, tak stejně jsem se vrhl do online marketingu, kde jsem se našel. Teď si plně spravuji firemní e-shop a řeším i marketingové věci kolem něj a to je přesně to, kam sem došel jenom díky FutureBakery. Předtím by mě to nikdy nenapadlo, ani bych se o tohle odvětví nezajímal, protože bych ho prostě neznal. Protože co nemám pod nosem, to nevidím.”\_"
link_text: 'JOIN US'
link: /contact
---

