---
slider:
    -
        title: 'THE FUTURE IS HERE'
        subheading: 'Top creative and strategic minds joined forces with the largest crowd of consumers.'
        link: /bakery-about
        image: image.jpg
    -
        title: 'TRUE INSIGHTS'
        subheading: 'We are eager to hear and listen to the crowd'
        link: /bakery-about
        image: shutterstock_771033703_small.jpg
    -
        title: 'FRESH IDEAS'
        subheading: 'Original content by and for your future consumers'
        link: /bakery-about
        image: shutterstock_155344466_small.jpg
    -
        title: 'INNOVATIONS AND IDEAS FOR REAL LIFE'
        subheading: 'Not the presentation decks'
        link: /bakery-about
        image: shutterstock_1159947316_small.jpg
media: 'image.jpg,shutterstock_155344466_small.jpg,shutterstock_771033703_small.jpg,shutterstock_1159947316_small.jpg'
title: Bakery
visible: false
---

