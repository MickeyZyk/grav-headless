---
title: DAS
logo_dark: DAS.png
heading_tag: 'Creative Strategy'
heading_one: 'How do you explain and sell the legal insurance to people that are afraid of lawyers and hate insurance houses?'
one_way: 'Tell the consumers about unique benefits of your product.'
new_way: 'How about not selling insurance, but “help the good ” instead?'
big_image: DAS_video_back.jpg
video: 'https://youtu.be/y2Q2tjT8qh4'
logo_light: DAS.png
heading_two: 'DAS CASE STUDY'
media: DAS.png
---

