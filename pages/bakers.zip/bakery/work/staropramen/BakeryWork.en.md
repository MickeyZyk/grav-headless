---
title: Staropramen
logo_dark: 'Logo_Pivovary Staropramen-a.png'
heading_tag: 'Strategic Planning & Consultancy, Creative Strategy'
heading_one: 'How to kick a national brand of beer? How to help it grow?'
one_way: 'Play the beer fun (Nobody believes that is funny)'
new_way: 'Exploring the place of origin, its people and their specific way of life.'
big_image: fiat_video.jpg
video: 'https://youtu.be/KCela48LYuo'
logo_light: 'Logo_Pivovary Staropramen-a.png'
category: AWARD
category_name: '???'
heading_two: 'Staropramen CaseStudy'
media: 'Logo_Pivovary Staropramen-a.png'
---

