---
title: Mazda
logo_dark: dark_logo_fiat.png
heading_one: 'How do you explain and sell the legal insurance to people that are afraid of lawyers and hate insurance houses?'
one_way: 'Tell the consumers about unique benefits of your product.'
new_way: 'How about not selling insurance, but help the good instead?'
big_image: fiat_video.jpg
video: 9HQLdSHOHxU
logo_light: light_logo_fiat.png
category: AWARD
category_name: 'FIAT 500X'
heading_two: 'BEAUTY AND FUNCTION COMBINED'
media: 'dark_logo_fiat.png,fiat_video.jpg,light_logo_fiat.png'
---

