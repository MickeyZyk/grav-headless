---
title: 'Homepage Slider'
visible: false
content:
    items: '@self.children'
---

