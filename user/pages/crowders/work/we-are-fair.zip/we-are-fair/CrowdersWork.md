---
title: 'We are fair'
heading_tag: 'Community building '
heading_one: 'Let’s be fair'
paragraph: "Opening the topic of The rights to gay marriage\r\nPlatform for social opinion, approach and questions on topic “What is fair”\r\nCreating nationwide topic\r\nNatural influence on politicians and major opinion"
---

