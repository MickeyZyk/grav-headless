---
name: Slide2
heading: 'TRUE INSIGHTS'
subheading: 'Top creative and strategic minds joined forces with the largest crowd of consumers'
link: /more
image:
    assets/uploads/image.jpg:
        name: image.jpg
        type: image/jpeg
        size: 243686
        path: assets/uploads/image.jpg
subheader: 'Top creative and strategic minds joined forces with the largest crowd of consumers.'
title: Slide2
---

