---
name: Slide3
heading: 'GARDEN OF DREAMS'
subheading: 'Top creative and strategic minds joined forces'
link: /more
title: Slide3
image:
    assets/uploads/blue.jpg:
        name: blue.jpg
        type: image/jpeg
        size: 137165
        path: assets/uploads/blue.jpg
---

