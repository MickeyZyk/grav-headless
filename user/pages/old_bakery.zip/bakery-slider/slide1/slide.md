---
name: Slide1
heading: 'THE FUTURE IS HERE'
subheading: 'Top creative and strategic minds joined forces with the largest crowd of consumers'
link: /more
image:
    assets/uploads/dude.jpg:
        name: dude.jpg
        type: image/jpeg
        size: 187744
        path: assets/uploads/dude.jpg
subheader: 'Top creative and strategic minds joined forces with the largest crowd of consumers.'
title: Slide1
---

