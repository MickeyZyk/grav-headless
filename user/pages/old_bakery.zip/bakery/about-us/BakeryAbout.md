---
title: 'About Us'
heading_one: 'One way or new way.'
paragraph_one: 'We have liaised top creative and strategic minds with creativity, life experience and levity of thousands people from the crowd. People who don’t sit in the office or development centre, but have a real life… with real problems and needs. We link ideas and insights, trends or strategies. We look for future. We seek diversity, new perspective and link together what seems incompatible. We listen and get inspired by the crowd. We look into numbers but do not make the average. We regularly check “temperature” to know what people really feel. We want to know what our future will look like and we want to participate on it. We help individuals as well as organizations to find their place in the future. We fuel the brands with relevant product and experience concepts, offer a fresh perspective on your business and ideate original campaign ideas.'
image_one:
    assets/uploads/desk.jpg:
        name: desk.jpg
        type: image/jpeg
        size: 456507
        path: assets/uploads/desk.jpg
---

